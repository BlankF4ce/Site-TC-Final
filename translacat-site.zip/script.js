const translations = {
  pt: {
    'nav-services': 'Serviços','nav-clients': 'Clientes','nav-projects': 'Projetos',
    'nav-about': 'Sobre','nav-contact': 'Contato','nav-cta': 'Solicitar Orçamento',
    'hero-badge': '🎮 Games · TI · Engenharia · Literatura',
    'hero-title': 'Precisão em<br>cada <span class="acc">palavra.</span><br>Paixão em<br>cada projeto.',
    'hero-sub': 'Tradução e localização especializada para games, TI e engenharia técnica. +10 milhões de palavras traduzidas. Parceiros de líderes globais.',
    'btn-orcamento': 'Solicitar Orçamento','btn-portfolio': 'Ver Portfólio',
    'trusted-label': 'Confiado por líderes globais',
    'philo-label': 'Filosofia',
    'philo-q1': '"A tradução não é substituição de palavras."',
    'philo-masim': 'mas sim',
    'philo-q2': '"É transplante de significado entre culturas."',
    'philo-big1': 'Enquanto outros traduzem <span style="color:var(--red);font-style:italic">palavras,</span>',
    'philo-big2': 'nós localizamos <span style="color:var(--red);font-style:italic">experiências.</span>',
    'svc-label': 'O que fazemos','svc-title': 'Nossos Serviços',
    'svc-desc': 'Uma equipe diversificada com especialistas em tradução literária, áudio, sistema e visual — tudo sob um mesmo teto.',
    'svc1-name': 'Games & Videogames','svc1-txt': 'Localização completa de jogos: interface, motor, dublagem, marketing e LQA. Atuamos desde casual games até os maiores títulos do mercado global.','svc1-lnk': 'Saiba Mais',
    'svc2-name': 'TI & Software','svc2-txt': 'Tradução de interfaces, documentação técnica e materiais de marketing para empresas como Apple, Microsoft, Google, IBM e dezenas de outras.','svc2-lnk': 'Saiba Mais',
    'svc3-name': 'Engenharia & Técnico','svc3-txt': 'Milhões de palavras traduzidas em manuais de maquinário pesado e documentação automotiva para Caterpillar, Scania, Rolls Royce e outros.','svc3-lnk': 'Saiba Mais',
    'svc4-name': 'Literatura & Cultura','svc4-txt': 'Tradução de romances, séries de aventura e conteúdo cultural disponíveis no Amazon.com.br, além de mangas e material audiovisual.','svc4-lnk': 'Saiba Mais',
    'proj-label': 'Portfólio','proj-title': 'Projetos em Destaque','btn-portfolio-full': 'Ver Portfólio Completo',
    'mq-label': 'Mais de 500 jogos localizados para clientes ao redor do mundo',
    'ab-label': 'Sobre & Qualificações','ab-title': 'Paixão que vira resultado profissional',
    'ab1-t': '+25 anos de experiência combinada em TI','ab1-d': 'Nossa fundadora trabalhou por mais de 25 anos como programadora, analista de sistemas e analista de redes no governo federal — antes de se tornar referência em tradução técnica.',
    'ab2-t': 'Credenciada pelo Ministério da Educação','ab2-d': 'Tradutora reconhecida pelo MEC, com histórico como Lead Linguist na localização de World of Warcraft pela Blizzard Entertainment para o português brasileiro.',
    'ab3-t': 'Domínio de todas as ferramentas CAT','ab3-d': 'Uma das poucas empresas com domínio prático em praticamente todas as ferramentas de tradução assistida por computador disponíveis no mercado.',
    'ab4-t': 'Equipe diversificada e especializada','ab4-d': 'Especialistas em tradução literária, áudio, sistema e visual. PMs sêniores, tradutores criativos, revisores e localizadores de game engine.',
    'stat1-l': 'Palavras traduzidas','stat2-l': 'Jogos localizados','stat3-l': 'Anos de mercado','stat4-l': 'Áreas de especialização',
    'tags-lbl': 'Principais clientes de TI',
    'team-label': 'Nossa Equipe','team-title': 'Quem está por trás da TranslaCAT','team-desc': 'Um trio de especialistas apaixonados por linguagem, tecnologia e a arte de comunicar com precisão.',
    'cj-role': 'Fundadora · Lead Linguist','cj-bio': 'Mais de 25 anos como programadora e analista de sistemas no governo federal. Lead Linguist na localização de World of Warcraft pela Blizzard. Com mais de 10 milhões de palavras traduzidas, é conhecida como "máquina de tradução" e "glossário humano" pelo rigor ímpar na escrita técnica.',
    'dz-role': 'Lead Linguist · Diretor Criativo','dz-bio': 'Farmacêutico de formação, tradutor por vocação. Graduado em Tradução pela Universidade Gama Filho e Lead Linguist em WoW pela Blizzard. Especialista em games e textos técnicos, é o pilar criativo da equipe — apaixonado por línguas, poesia e até pelo latim.',
    'kj-role': 'QA Manager · Revisora Sênior','kj-bio': 'Filha de Christiane, começou a traduzir cedo seguindo os passos da mãe. Encontrou seu caminho no QA, revisão e controle de qualidade na localização de World of Warcraft. Guardiã da qualidade da TranslaCAT — pequena em estatura, grande em capacidade.',
    'cta-title': 'Pronto para o seu próximo projeto?','cta-sub': 'Entre em contato e descubra como a TranslaCAT pode levar seu conteúdo para o público brasileiro com precisão e paixão.',
    'ft-desc': 'Tradução e localização especializada para games, TI e engenharia. Translate + CAT — Computer Assisted Translation.',
    'ft-links-t': 'Links','ft-svc-t': 'Serviços','ft-cli-t': 'Clientes',
    'ft-copy': '© 2024 TranslaCAT. Todos os direitos reservados. Powered by TranslaCAT.',
  },
  en: {
    'nav-services': 'Services','nav-clients': 'Clients','nav-projects': 'Projects',
    'nav-about': 'About','nav-contact': 'Contact','nav-cta': 'Request a Quote',
    'hero-badge': '🎮 Games · IT · Engineering · Literature',
    'hero-title': 'Precision in<br>every <span class="acc">word.</span><br>Passion in<br>every project.',
    'hero-sub': 'Specialized translation and localization for games, IT and technical engineering. 10M+ words translated. Trusted by global leaders.',
    'btn-orcamento': 'Request a Quote','btn-portfolio': 'View Portfolio',
    'trusted-label': 'Trusted by global leaders',
    'philo-label': 'Philosophy',
    'philo-q1': '"Translation is not the substitution of words."',
    'philo-masim': 'but rather',
    'philo-q2': '"It is the transplant of meaning between cultures."',
    'philo-big1': 'While others translate <span style="color:var(--red);font-style:italic">words,</span>',
    'philo-big2': 'we localize <span style="color:var(--red);font-style:italic">experiences.</span>',
    'svc-label': 'What we do','svc-title': 'Our Services',
    'svc-desc': 'A diverse team with specialists in literary, audio, system and visual translation — all under one roof.',
    'svc1-name': 'Games & Videogames','svc1-txt': 'Full game localization: UI, engine, dubbing, marketing and LQA. From casual games to the biggest titles in the global market.','svc1-lnk': 'Learn More',
    'svc2-name': 'IT & Software','svc2-txt': 'Translation of interfaces, technical documentation and marketing materials for companies like Apple, Microsoft, Google, IBM and dozens more.','svc2-lnk': 'Learn More',
    'svc3-name': 'Engineering & Technical','svc3-txt': 'Millions of words translated in heavy machinery manuals and automotive documentation for Caterpillar, Scania, Rolls Royce and others.','svc3-lnk': 'Learn More',
    'svc4-name': 'Literature & Culture','svc4-txt': 'Translation of novels, adventure series and cultural content available on Amazon.com.br, plus manga and audiovisual material.','svc4-lnk': 'Learn More',
    'proj-label': 'Portfolio','proj-title': 'Featured Projects','btn-portfolio-full': 'View Full Portfolio',
    'mq-label': 'Over 500 games localized for clients around the world',
    'ab-label': 'About & Qualifications','ab-title': 'Passion that delivers professional results',
    'ab1-t': '25+ years of combined IT experience','ab1-d': 'Our founder worked for over 25 years as a programmer, systems analyst and network analyst for the Brazilian federal government — before becoming a reference in technical translation.',
    'ab2-t': 'Certified by the Ministry of Education','ab2-d': 'MEC-recognized translator, with a track record as Lead Linguist in the localization of World of Warcraft by Blizzard Entertainment into Brazilian Portuguese.',
    'ab3-t': 'Mastery of all CAT tools','ab3-d': 'One of the few companies with practical mastery of virtually every computer-assisted translation tool available on the market.',
    'ab4-t': 'Diverse and specialized team','ab4-d': 'Specialists in literary, audio, system and visual translation. Senior PMs, creative translators, proofreaders and game engine localizers.',
    'stat1-l': 'Words translated','stat2-l': 'Games localized','stat3-l': 'Years in market','stat4-l': 'Areas of expertise',
    'tags-lbl': 'Key IT clients',
    'team-label': 'Our Team','team-title': 'The people behind TranslaCAT','team-desc': 'A trio of specialists passionate about language, technology and the art of communicating with precision.',
    'cj-role': 'Founder · Lead Linguist','cj-bio': 'Over 25 years as a programmer and systems analyst for the federal government. Lead Linguist in the localization of World of Warcraft by Blizzard. With over 10 million words translated, she is known as the "translation machine" and "human glossary" for her unmatched precision in technical writing.',
    'dz-role': 'Lead Linguist · Creative Director','dz-bio': 'Pharmacist by training, translator by vocation. Graduated in Translation from Universidade Gama Filho and Lead Linguist on WoW by Blizzard. Specialist in games and technical texts, the creative pillar of the team — passionate about languages, poetry and even Latin.',
    'kj-role': 'QA Manager · Senior Proofreader','kj-bio': "Christiane's daughter, she began translating early on in her mother's footsteps. She found her path in QA, proofreading and quality control during the World of Warcraft localization. TranslaCAT's quality guardian — small in stature, great in capacity.",
    'cta-title': 'Ready for your next project?','cta-sub': 'Get in touch and discover how TranslaCAT can bring your content to Brazilian audiences with precision and passion.',
    'ft-desc': 'Specialized translation and localization for games, IT and engineering. Translate + CAT — Computer Assisted Translation.',
    'ft-links-t': 'Links','ft-svc-t': 'Services','ft-cli-t': 'Clients',
    'ft-copy': '© 2024 TranslaCAT. All rights reserved. Powered by TranslaCAT.',
  }
};

let currentLang = 'pt';

function toggleLang() {
  currentLang = currentLang === 'pt' ? 'en' : 'pt';
  applyLang(currentLang);
  document.getElementById('lang-btn').textContent = currentLang === 'pt' ? 'EN' : 'PT';
}

function applyLang(lang) {
  const t = translations[lang];
  const set = (id, val) => { const el = document.getElementById(id); if(el) el.innerHTML = val; };
  const setText = (id, val) => { const el = document.getElementById(id); if(el) el.textContent = val; };
  set('nav-services',t['nav-services']); set('nav-clients',t['nav-clients']); set('nav-projects',t['nav-projects']); set('nav-about',t['nav-about']); set('nav-contact',t['nav-contact']); set('nav-cta',t['nav-cta']);
  set('hero-badge',t['hero-badge']); set('hero-title',t['hero-title']); set('hero-sub',t['hero-sub']);
  set('btn-orcamento',t['btn-orcamento']); set('btn-portfolio',t['btn-portfolio']);
  setText('trusted-label',t['trusted-label']);
  setText('philo-label',t['philo-label']); setText('philo-q1',t['philo-q1']); setText('philo-masim',t['philo-masim']); setText('philo-q2',t['philo-q2']);
  set('philo-big1',t['philo-big1']); set('philo-big2',t['philo-big2']);
  setText('svc-label',t['svc-label']); setText('svc-title',t['svc-title']); setText('svc-desc',t['svc-desc']);
  setText('svc1-name',t['svc1-name']); setText('svc1-txt',t['svc1-txt']); setText('svc1-lnk',t['svc1-lnk']);
  setText('svc2-name',t['svc2-name']); setText('svc2-txt',t['svc2-txt']); setText('svc2-lnk',t['svc2-lnk']);
  setText('svc3-name',t['svc3-name']); setText('svc3-txt',t['svc3-txt']); setText('svc3-lnk',t['svc3-lnk']);
  setText('svc4-name',t['svc4-name']); setText('svc4-txt',t['svc4-txt']); setText('svc4-lnk',t['svc4-lnk']);
  setText('proj-label',t['proj-label']); setText('proj-title',t['proj-title']); set('btn-portfolio-full',t['btn-portfolio-full']);
  setText('mq-label',t['mq-label']);
  setText('ab-label',t['ab-label']); setText('ab-title',t['ab-title']);
  setText('ab1-t',t['ab1-t']); setText('ab1-d',t['ab1-d']); setText('ab2-t',t['ab2-t']); setText('ab2-d',t['ab2-d']);
  setText('ab3-t',t['ab3-t']); setText('ab3-d',t['ab3-d']); setText('ab4-t',t['ab4-t']); setText('ab4-d',t['ab4-d']);
  setText('stat1-l',t['stat1-l']); setText('stat2-l',t['stat2-l']); setText('stat3-l',t['stat3-l']); setText('stat4-l',t['stat4-l']);
  setText('tags-lbl',t['tags-lbl']);
  setText('team-label',t['team-label']); setText('team-title',t['team-title']); setText('team-desc',t['team-desc']);
  setText('cj-role',t['cj-role']); setText('cj-bio',t['cj-bio']);
  setText('dz-role',t['dz-role']); setText('dz-bio',t['dz-bio']);
  setText('kj-role',t['kj-role']); setText('kj-bio',t['kj-bio']);
  setText('cta-title',t['cta-title']); setText('cta-sub',t['cta-sub']);
  setText('ft-desc',t['ft-desc']); setText('ft-links-t',t['ft-links-t']); setText('ft-svc-t',t['ft-svc-t']); setText('ft-cli-t',t['ft-cli-t']);
  setText('ft-copy',t['ft-copy']);
}